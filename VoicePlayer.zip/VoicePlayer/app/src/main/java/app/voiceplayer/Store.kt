package app.voiceplayer

import android.content.Context
import android.content.SharedPreferences

/** Избранное, недавние и плейлисты. Тот же файл "vp" и те же ключи, что у голосовых команд. */
object Store {
    private lateinit var prefs: SharedPreferences

    fun init(ctx: Context) {
        if (!::prefs.isInitialized) {
            prefs = ctx.applicationContext.getSharedPreferences("vp", Context.MODE_PRIVATE)
        }
    }

    private fun copySet(key: String): MutableSet<String> =
        HashSet(prefs.getStringSet(key, emptySet()) ?: emptySet())

    fun favIds(): Set<String> = prefs.getStringSet("fav", emptySet()) ?: emptySet()
    fun isFav(id: Long): Boolean = favIds().contains(id.toString())

    fun toggleFav(id: Long): Boolean {
        val f = copySet("fav")
        val k = id.toString()
        val now = if (f.contains(k)) { f.remove(k); false } else { f.add(k); true }
        prefs.edit().putStringSet("fav", f).apply()
        return now
    }

    fun banned(): Set<String> = prefs.getStringSet("ban", emptySet()) ?: emptySet()

    fun recentIds(): List<String> =
        (prefs.getString("recent", "") ?: "").split(",").filter { it.isNotEmpty() }

    fun addRecent(id: String) {
        if (!::prefs.isInitialized) return
        val l = recentIds().toMutableList()
        l.remove(id)
        l.add(0, id)
        while (l.size > 50) l.removeAt(l.size - 1)
        prefs.edit().putString("recent", l.joinToString(",")).apply()
    }

    fun playlistNames(): List<String> = copySet("pl_names").toList().sortedBy { it.lowercase() }

    fun playlistIds(name: String): List<String> =
        (prefs.getString("pl:$name", "") ?: "").split(",").filter { it.isNotEmpty() }

    fun savePlaylist(name: String, ids: List<String>) {
        val names = copySet("pl_names")
        names.add(name)
        prefs.edit()
            .putString("pl:$name", ids.joinToString(","))
            .putStringSet("pl_names", names)
            .apply()
    }

    fun deletePlaylist(name: String) {
        val names = copySet("pl_names")
        names.remove(name)
        prefs.edit().remove("pl:$name").putStringSet("pl_names", names).apply()
    }
}
