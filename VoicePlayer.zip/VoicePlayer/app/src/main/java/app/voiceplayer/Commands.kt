package app.voiceplayer

import android.content.Context
import android.media.AudioManager
import androidx.media3.common.Player

/** Разбор голосовых команд. handle() возвращает фразу-ответ. */
class Commands(ctx: Context) {
    private val p get() = PlayerHolder.player
    private val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val prefs = ctx.getSharedPreferences("vp", Context.MODE_PRIVATE)

    companion object {
        const val NO_LIB = "Не нашёл музыку на устройстве. Проверьте доступ к аудио в настройках."
        const val HELP = "Я умею: включи название, исполнителя или альбом; пауза; дальше; назад; " +
            "перемотай на 1:30; вперёд на 30 секунд; таймер сна на 20 минут; громче, тише, громкость 50; " +
            "скорость 1.5; перемешай; повтор; в избранное; включи избранное; что играет; сколько осталось."
        private val playVerb = Regex("^(включи|включай|врубай|запусти|играй|сыграй|поставь|воспроизведи|найди|давай|play)( |$)")
        private val filler = setOf(
            "включи", "включай", "врубай", "запусти", "играй", "сыграй", "поставь", "воспроизведи",
            "найди", "давай", "мне", "песню", "песня", "песни", "трек", "композицию", "музыку",
            "музыка", "группы", "группу", "исполнителя", "певца", "артиста", "альбом", "альбома",
            "из", "от", "называется", "под", "названием", "мою", "play", "the", "еще", "теперь",
            "сейчас", "а", "ну", "и"
        )
    }

    private fun playList(list: List<Track>, start: Int = 0) {
        p.setMediaItems(list.map { it.item }, start, 0L)
        p.prepare()
        p.play()
    }

    private fun favs(): MutableSet<String> = HashSet(prefs.getStringSet("fav", emptySet()) ?: emptySet())
    private fun saveFavs(s: Set<String>) { prefs.edit().putStringSet("fav", s).apply() }

    private fun nowText(): String {
        val m = p.currentMediaItem?.mediaMetadata ?: return "Сейчас ничего не играет"
        return "Сейчас играет ${m.title}, исполнитель ${m.artist}"
    }

    fun handle(raw: String): String {
        val t = Ru.norm(raw)
            .replace(Regex("(^| )(пожалуйста|плиз|плеер|player|эй|окей|ок|слушай)(?= |$)"), " ")
            .replace(Regex("\\s+"), " ").trim()
        if (t.isEmpty()) return "Слушаю"
        val tn = Ru.numberize(t)
        val lib = MusicLibrary.tracks
        fun has(vararg k: String) = k.any { t.contains(it) }

        val dur = Ru.parseDuration(tn)
        val clock = Ru.parseClock(tn)
        val amount: Long? = clock ?: dur
        val startsPlay = playVerb.containsMatchIn(t)

        if (has("что ты умеешь", "что умеешь", "помощь", "какие команды")) return HELP

        // ---- таймер сна ----
        if (has("таймер") && has("отмен", "отключ", "выключ", "убери", "сбрось", "останов", "удали") && dur == null) {
            PlayerHolder.cancelSleep()
            return "Таймер сна отключён"
        }
        if (has("сколько") && has("таймер", "до сна", "до выключения")) {
            val r = PlayerHolder.sleepRemaining()
            return if (r < 0) "Таймер сна не установлен" else "До выключения " + Ru.spoken(r)
        }
        val night = has("спокойной ночи", "иду спать", "ложусь спать")
        val sleepish = has("таймер", "засып") || night ||
            (has("через") && dur != null && has("стоп", "выключ", "останов", "пауз", "отключ"))
        if (sleepish) {
            if (has("до конца трека", "до конца песни", "до конца композиции")) {
                PlayerHolder.sleepAtTrackEnd()
                return "Остановлю музыку в конце этого трека"
            }
            val bare = Regex("(\\d+)").find(tn)?.value?.toLongOrNull()?.times(60_000L)
            val ms: Long = dur ?: bare ?: (if (night) 30 * 60_000L else null)
                ?: return "На сколько? Скажите, например: таймер сна на двадцать минут"
            PlayerHolder.startSleep(ms)
            return "Таймер сна на " + Ru.spoken(ms) + ". Музыка будет затихать"
        }

        // ---- перемотка ----
        val seekVerb = has("перемот", "промот", "отмот", "перейди на", "перейти на", "перескочи",
            "поставь на", "вернись на", "начни с", "сначала", "с начала", "в начало", "в начале", "заново", "seek")
        if (seekVerb || (has("вперед", "назад") && amount != null)) {
            val pos = p.currentPosition
            val d = p.duration
            val dir = when {
                has("отмот") || has("назад") -> -1
                has("вперед") -> 1
                else -> 0
            }
            var target: Long? = null
            var msg = ""
            when {
                has("сначала", "с начала", "в начало", "в начале", "заново") && amount == null -> {
                    target = 0L; msg = "С начала"
                }
                has("середин") && d > 0 -> { target = d / 2; msg = "На середину трека" }
                amount != null && dir != 0 -> {
                    target = pos + dir * amount
                    msg = (if (dir > 0) "Вперёд на " else "Назад на ") + Ru.spoken(amount)
                }
                amount != null -> { target = amount; msg = "Перемотал на " + Ru.fmt(amount) }
            }
            if (target != null) {
                val max = if (d > 0) d - 500 else Long.MAX_VALUE
                p.seekTo(target.coerceIn(0L, maxOf(0L, max)))
                return msg
            }
        }
        if (has("повтори") && !startsPlay) { p.seekTo(0L); p.play(); return "Повторяю трек" }

        // ---- скорость ----
        if (has("скорост", "быстрее", "медленнее", "темп воспроизведения")) {
            val cur = p.playbackParameters.speed
            val num = Regex("(\\d+(?:[.,]\\d+)?)").find(tn)?.value?.replace(',', '.')?.toFloatOrNull()
            val ns: Float? = when {
                has("обычн", "нормальн", "стандартн", "сброс") -> 1f
                has("полтора") -> 1.5f
                num != null -> num
                has("быстрее", "ускор", "увелич") -> cur + 0.25f
                has("медленнее", "замедл", "уменьш") -> cur - 0.25f
                else -> null
            }
            if (ns != null) {
                val v = ns.coerceIn(0.25f, 3f)
                p.setPlaybackSpeed(v)
                return "Скорость " + v.toString().removeSuffix(".0")
            }
        }

        // ---- громкость ----
        if (has("громк", "громче", "тише", "звук", "потише", "погромче", "прибавь", "убавь", "mute")) {
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val cur = am.getStreamVolume(AudioManager.STREAM_MUSIC)
            val step = maxOf(1, max / 10)
            val pct = Regex("(\\d{1,3})").find(tn)?.value?.toIntOrNull()
            val nv: Int? = when {
                has("без звука", "выключи звук", "mute") -> 0
                has("максимальн", "на полную") -> max
                has("минимальн") -> 1
                pct != null && has("громк", "звук") -> pct.coerceIn(0, 100) * max / 100
                has("громче", "погромче", "прибавь", "увелич") -> cur + step
                has("тише", "потише", "убавь", "уменьш") -> cur - step
                else -> null
            }
            if (nv != null) {
                val v = nv.coerceIn(0, max)
                am.setStreamVolume(AudioManager.STREAM_MUSIC, v, AudioManager.FLAG_SHOW_UI)
                return if (v == 0) "Звук выключен" else "Громкость " + (v * 100 / max) + " процентов"
            }
        }

        // ---- перемешивание / повтор ----
        if (has("перемеш", "шафл", "shuffle", "случайный порядок", "случайном порядке")) {
            val off = has("не ", "выключ", "отключ", "обычн")
            p.shuffleModeEnabled = !off
            return if (off) "Перемешивание выключено" else "Перемешивание включено"
        }
        if (Regex("повтор(?!и)").containsMatchIn(t) || has("зацикли", "по кругу")) {
            return when {
                has("выключ", "отключ", "не повтор", "без повтор") -> { p.repeatMode = Player.REPEAT_MODE_OFF; "Повтор выключен" }
                has("один", "этот", "текущ", "трек", "песн", "зацикли") -> { p.repeatMode = Player.REPEAT_MODE_ONE; "Повторяю этот трек" }
                else -> { p.repeatMode = Player.REPEAT_MODE_ALL; "Повторяю весь список" }
            }
        }

        // ---- избранное ----
        if (has("убери из избранн", "удали из избранн", "дизлайк", "убери из любим")) {
            val id = p.currentMediaItem?.mediaId ?: return "Сейчас ничего не играет"
            val f = favs(); f.remove(id); saveFavs(f)
            return "Убрал из избранного"
        }
        if (has("в избранное", "лайк", "в любимые", "мне нравится этот")) {
            val id = p.currentMediaItem?.mediaId ?: return "Сейчас ничего не играет"
            val f = favs(); f.add(id); saveFavs(f)
            return "Добавил в избранное"
        }
        if (has("избранн", "любимые", "любимое") && (startsPlay || has("включи", "играй"))) {
            val f = favs()
            val l = lib.filter { it.id.toString() in f }.shuffled()
            if (l.isEmpty()) return "В избранном пока пусто. Скажите «в избранное», пока играет трек"
            playList(l)
            return "Включаю избранное"
        }

        // ---- информация ----
        if (has("что играет", "что за песня", "что за трек", "как называется", "кто поет", "кто исполняет", "что это за")) {
            return nowText()
        }
        if (has("сколько песен", "сколько треков")) return "В библиотеке ${lib.size} " +
            Ru.plural(lib.size.toLong(), "трек", "трека", "треков")
        if (has("сколько осталось", "сколько до конца")) {
            val d = p.duration
            if (d <= 0) return "Сейчас ничего не играет"
            return "До конца трека " + Ru.spoken(d - p.currentPosition)
        }

        // ---- навигация ----
        if (has("следующ", "дальше", "пропусти", "скип", "next", "переключи", "другой трек", "другую песню")) {
            val n = (Regex("(\\d+)").find(tn)?.value?.toIntOrNull() ?: 1).coerceIn(1, 50)
            repeat(n) { p.seekToNextMediaItem() }
            p.play()
            return if (n > 1) "Пропускаю $n трека" else "Следующий трек"
        }
        if (has("предыдущ", "прошлый трек", "прошлую", "вернись", "previous", "назад")) {
            p.seekToPreviousMediaItem()
            p.play()
            return "Предыдущий трек"
        }

        // ---- пауза ----
        if (has("пауз", "стоп", "останов", "замолч", "хватит", "тишин", "выключи", "отключи", "помолчи", "stop") &&
            (!startsPlay || has("на паузу"))
        ) {
            p.pause()
            return "Пауза"
        }

        // ---- воспроизведение ----
        if (has("что нибудь", "любую", "случайн", "удиви", "наугад", "на твой выбор", "любой трек") &&
            (startsPlay || t.length < 25)
        ) {
            if (lib.isEmpty()) return NO_LIB
            playList(lib.shuffled())
            return "Включаю что-нибудь случайное"
        }
        if (has("недавно добавленн", "последние добавленн", "новинки", "новое", "свежее") && startsPlay) {
            if (lib.isEmpty()) return NO_LIB
            playList(lib.sortedByDescending { it.added }.take(50))
            return "Включаю недавно добавленное"
        }

        val query = t.split(" ").filter { it.isNotEmpty() && it !in filler }.joinToString(" ")
        if (query.isEmpty()) {
            if (p.mediaItemCount > 0) { p.play(); return "Продолжаю" }
            if (lib.isEmpty()) return NO_LIB
            playList(lib.shuffled())
            return "Включаю музыку"
        }
        if (lib.isEmpty()) return NO_LIB
        val res = MusicLibrary.search(query)
        if (res.isEmpty()) {
            return if (startsPlay) "Не нашёл «$query» в вашей музыке" else "Не понял команду: $raw"
        }
        val ids = res.map { it.id }.toHashSet()
        playList(res + lib.filter { it.id !in ids })
        val artists = res.map { it.artist }.distinct()
        return when {
            res.size == 1 -> "Включаю ${res[0].title}"
            artists.size == 1 -> "Включаю ${artists[0]}"
            else -> "Включаю: ${res[0].title}"
        }
    }
}
