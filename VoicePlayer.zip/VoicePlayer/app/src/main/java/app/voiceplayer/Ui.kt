package app.voiceplayer

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.media.MediaMetadataRetriever
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.LruCache
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

object Pal {
    val ACCENT = Color.parseColor("#B388FF")
    val DEEP = Color.parseColor("#8B5CF6")
    val SUB = Color.parseColor("#B9A8F5")
    val CARD_TOP = Color.parseColor("#5A3F2BA8")
    val CARD_BOT = Color.parseColor("#3D26137F")
    val STROKE = Color.parseColor("#70A98BFF")
    val NAV = Color.parseColor("#F0180A47")
    val RED = Color.parseColor("#E5486B")
    val GLOW = Color.parseColor("#33B388FF")
    val CHIP = Color.parseColor("#2AFFFFFF")
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density

fun Context.glass(radiusDp: Int): GradientDrawable =
    GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Pal.CARD_TOP, Pal.CARD_BOT)).apply {
        cornerRadius = dpf(radiusDp.toFloat())
        setStroke(dp(1), Pal.STROKE)
    }

fun Context.pressable(radiusDp: Int): Drawable {
    val mask = GradientDrawable().apply {
        cornerRadius = dpf(radiusDp.toFloat())
        setColor(Color.WHITE)
    }
    return RippleDrawable(ColorStateList.valueOf(Color.parseColor("#33FFFFFF")), glass(radiusDp), mask)
}

fun Context.icon(res: Int, tint: Int = Color.WHITE): ImageView = ImageView(this).apply {
    setImageResource(res)
    imageTintList = ColorStateList.valueOf(tint)
}

fun Context.tv(text: String, sp: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
    this.text = text
    textSize = sp
    setTextColor(color)
    if (bold) setTypeface(null, Typeface.BOLD)
}

fun lp(w: Int, h: Int, weight: Float = 0f, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0): LinearLayout.LayoutParams =
    LinearLayout.LayoutParams(w, h, weight).apply { setMargins(l, t, r, b) }

fun plTracks(n: Int): String {
    val m100 = n % 100
    val m10 = n % 10
    val w = if (m100 in 11..14) "треков" else when (m10) {
        1 -> "трек"
        2, 3, 4 -> "трека"
        else -> "треков"
    }
    return "$n $w"
}

/** Фон: тёмно-фиолетовый градиент, облака и звёзды. */
class BgView(ctx: Context) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val stars = run {
        val rnd = java.util.Random(11)
        List(52) { floatArrayOf(rnd.nextFloat(), rnd.nextFloat(), 1.2f + rnd.nextFloat() * 3.2f, 0.25f + rnd.nextFloat() * 0.6f) }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        paint.shader = LinearGradient(
            0f, 0f, 0f, h,
            intArrayOf(Color.parseColor("#0A0321"), Color.parseColor("#1C0B52"), Color.parseColor("#0B0325")),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w, h, paint)
        cloud(c, w * 0.95f, h * 0.02f, w * 0.55f, "#6640209F")
        cloud(c, w * 0.05f, h * 0.38f, w * 0.45f, "#44371A8C")
        cloud(c, w * 0.9f, h * 0.88f, w * 0.7f, "#774A24B8")
        cloud(c, w * 0.1f, h * 0.97f, w * 0.6f, "#665B2FD0")
        paint.shader = null
        for (s in stars) {
            val x = s[0] * w
            val y = s[1] * h
            paint.color = Color.argb((s[3] * 255).toInt(), 205, 180, 255)
            if (s[2] > 3.0f) {
                val k = s[2] * 3f
                path.reset()
                path.moveTo(x, y - k)
                path.quadTo(x, y, x + k, y)
                path.quadTo(x, y, x, y + k)
                path.quadTo(x, y, x - k, y)
                path.quadTo(x, y, x, y - k)
                path.close()
                c.drawPath(path, paint)
            } else {
                c.drawCircle(x, y, s[2] * 0.6f, paint)
            }
        }
    }

    private fun cloud(c: Canvas, cx: Float, cy: Float, r: Float, argb: String) {
        val col = Color.parseColor(argb)
        paint.shader = RadialGradient(cx, cy, r, col, col and 0x00FFFFFF, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r, paint)
    }
}

/** Анимированные столбики эквалайзера. */
class EqBars(ctx: Context) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Pal.ACCENT }
    private var active = false

    fun setActive(a: Boolean) {
        if (active != a) { active = a; invalidate() }
    }

    override fun onDraw(c: Canvas) {
        val n = 4
        val w = width.toFloat()
        val h = height.toFloat()
        val gap = w * 0.12f
        val bw = (w - gap * (n - 1)) / n
        val t = SystemClock.uptimeMillis() / 1000.0
        for (i in 0 until n) {
            val f = if (active) (0.3 + 0.7 * Math.abs(Math.sin(t * 4.0 + i * 1.7))).toFloat() else 0.3f + 0.12f * i
            val bh = h * f
            val x = i * (bw + gap)
            c.drawRoundRect(x, h - bh, x + bw, h, bw / 2, bw / 2, paint)
        }
        if (active) postInvalidateOnAnimation()
    }
}

/** Загрузка обложек в фоне. */
object Covers {
    private val cache = LruCache<Long, Bitmap>(30)
    private val missing = ConcurrentHashMap.newKeySet<Long>()
    private val ex = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    fun load(ctx: Context, t: Track, cb: (Bitmap?) -> Unit) {
        val hit = cache.get(t.id)
        if (hit != null) { cb(hit); return }
        if (missing.contains(t.id)) { cb(null); return }
        val app = ctx.applicationContext
        ex.execute {
            var bmp: Bitmap? = null
            try {
                if (Build.VERSION.SDK_INT >= 29) {
                    bmp = app.contentResolver.loadThumbnail(t.uri, Size(400, 400), null)
                }
            } catch (_: Exception) {
            }
            if (bmp == null) {
                try {
                    val r = MediaMetadataRetriever()
                    try {
                        r.setDataSource(app, t.uri)
                        val b = r.embeddedPicture
                        if (b != null) bmp = BitmapFactory.decodeByteArray(b, 0, b.size)
                    } finally {
                        r.release()
                    }
                } catch (_: Exception) {
                }
            }
            val result = bmp
            if (result != null) cache.put(t.id, result) else missing.add(t.id)
            main.post { cb(result) }
        }
    }
}

private val PALETTE = arrayOf(
    intArrayOf(Color.parseColor("#7C4DFF"), Color.parseColor("#2A1070")),
    intArrayOf(Color.parseColor("#B44CFF"), Color.parseColor("#4A1C9E")),
    intArrayOf(Color.parseColor("#3D7BFF"), Color.parseColor("#22126E")),
    intArrayOf(Color.parseColor("#FF5FA8"), Color.parseColor("#5B1A8C")),
    intArrayOf(Color.parseColor("#7A5CFF"), Color.parseColor("#1A0F5C"))
)

/** Скруглённая обложка: градиент-заглушка + иконка, поверх — настоящая картинка, если нашлась. */
class CoverView(ctx: Context, radiusDp: Int) : FrameLayout(ctx) {
    private val icon = ImageView(ctx)
    private val img = ImageView(ctx)
    private var token: Long = -1

    init {
        val r = ctx.dpf(radiusDp.toFloat())
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, r)
            }
        }
        clipToOutline = true
        icon.imageTintList = ColorStateList.valueOf(Color.parseColor("#CCFFFFFF"))
        val s = ctx.dp(24)
        addView(icon, FrameLayout.LayoutParams(s, s, Gravity.CENTER))
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        img.visibility = View.GONE
        addView(img, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    fun bindSeed(seed: Int, iconRes: Int) {
        background = GradientDrawable(GradientDrawable.Orientation.TL_BR, PALETTE[Math.abs(seed % PALETTE.size)])
        icon.setImageResource(iconRes)
    }

    fun bindTrack(t: Track?) {
        if (t == null) {
            token = -1
            img.visibility = View.GONE
            bindSeed(0, R.drawable.ic_music)
            return
        }
        bindSeed(t.id.toInt(), R.drawable.ic_music)
        if (token == t.id && img.visibility == View.VISIBLE) return
        token = t.id
        img.visibility = View.GONE
        Covers.load(context, t) { bmp ->
            if (token == t.id && bmp != null) {
                img.setImageBitmap(bmp)
                img.visibility = View.VISIBLE
            }
        }
    }
}
