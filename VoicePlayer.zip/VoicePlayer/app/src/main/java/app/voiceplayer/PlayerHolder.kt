package app.voiceplayer

import android.app.Application
import android.media.audiofx.BassBoost
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer

/** Единый плеер на весь процесс + таймер сна + бас. */
object PlayerHolder {
    lateinit var player: ExoPlayer
        private set

    private val h = Handler(Looper.getMainLooper())
    private val attrs = AudioAttributes.Builder()
        .setUsage(C.USAGE_MEDIA)
        .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
        .build()
    private var duck = 1f
    private var fade = 1f
    private var sleepEnd = 0L
    var trackEndMode = false
    private var bass: BassBoost? = null
    var bassStrength = 0
        private set

    private val tick = object : Runnable {
        override fun run() {
            val rem = sleepEnd - SystemClock.elapsedRealtime()
            if (rem <= 0) {
                player.pause()
                sleepEnd = 0L
                fade = 1f
                applyVol()
                return
            }
            fade = if (rem < 15_000) rem / 15_000f else 1f
            applyVol()
            h.postDelayed(this, 500)
        }
    }

    fun init(app: Application) {
        if (::player.isInitialized) return
        Store.init(app)
        player = ExoPlayer.Builder(app)
            .setAudioAttributes(attrs, true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
        player.addListener(object : Player.Listener {
            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                if (reason == Player.PLAY_WHEN_READY_CHANGE_REASON_END_OF_MEDIA_ITEM) {
                    player.pauseAtEndOfMediaItems = false
                    trackEndMode = false
                }
            }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val id = mediaItem?.mediaId
                if (!id.isNullOrEmpty()) Store.addRecent(id)
            }
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                try { bass?.release() } catch (_: Exception) {}
                bass = null
                applyBass()
            }
        })
    }

    fun isReady() = ::player.isInitialized

    /** Пока слушаем в фоне, распознаватель не должен ставить музыку на паузу. */
    fun setFocusHandling(on: Boolean) { player.setAudioAttributes(attrs, on) }

    private fun applyVol() { player.volume = duck * fade }
    fun setDuck(v: Float) { duck = v; applyVol() }

    fun setBass(s: Int) { bassStrength = s.coerceIn(0, 1000); applyBass() }

    private fun applyBass() {
        try {
            if (player.audioSessionId == C.AUDIO_SESSION_ID_UNSET) return
            if (bass == null) bass = BassBoost(0, player.audioSessionId)
            bass?.setStrength(bassStrength.toShort())
            bass?.enabled = bassStrength > 0
        } catch (_: Exception) {
        }
    }

    fun startSleep(ms: Long) {
        cancelSleep()
        sleepEnd = SystemClock.elapsedRealtime() + ms
        h.post(tick)
    }

    fun sleepAtTrackEnd() {
        cancelSleep()
        trackEndMode = true
        player.pauseAtEndOfMediaItems = true
    }

    fun cancelSleep() {
        h.removeCallbacks(tick)
        sleepEnd = 0L
        fade = 1f
        trackEndMode = false
        player.pauseAtEndOfMediaItems = false
        applyVol()
    }

    /** Миллисекунды до выключения или -1, если таймер не установлен. */
    fun sleepRemaining(): Long =
        if (sleepEnd == 0L) -1L else maxOf(0L, sleepEnd - SystemClock.elapsedRealtime())
}
