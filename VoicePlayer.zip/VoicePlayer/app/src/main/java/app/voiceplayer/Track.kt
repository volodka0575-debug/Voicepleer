package app.voiceplayer

import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata

data class Track(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val uri: Uri,
    val added: Long,
    val path: String = ""
) {
    val hay: String by lazy { Ru.collapse(Ru.norm("$title $artist $album")) }
    val hayTr: String by lazy { Ru.collapse(Ru.translit(Ru.norm("$title $artist $album"))) }

    val item: MediaItem by lazy {
        MediaItem.Builder()
            .setMediaId(id.toString())
            .setUri(uri)
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(title)
                    .setArtist(artist)
                    .setAlbumTitle(album)
                    .build()
            )
            .build()
    }

    val label: String get() = "$title — $artist"
}
