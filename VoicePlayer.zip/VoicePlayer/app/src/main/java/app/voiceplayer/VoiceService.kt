package app.voiceplayer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Фоновое слушание: «<имя плеера>, следующая» работает при закрытом приложении и выключенном экране.
 */
class VoiceService : Service() {
    companion object {
        @Volatile
        var instance: VoiceService? = null
        const val ACTION_STOP = "app.voiceplayer.STOP_VOICE"
        private const val CH = "voice_listen"

        fun start(ctx: Context) {
            val i = Intent(ctx, VoiceService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }

        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, VoiceService::class.java)) }
    }

    private val h = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var listening = false
    private var paused = false
    private var speaking = false
    private var offline = true
    private var followUntil = 0L
    private var wl: PowerManager.WakeLock? = null
    private lateinit var cmds: Commands

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            getSharedPreferences("vp", MODE_PRIVATE).edit().putBoolean("always", false).apply()
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        Wake.load(applicationContext)
        cmds = Commands(applicationContext)
        try {
            goForeground()
        } catch (e: Exception) {
            stopSelf()
            return
        }
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "voiceplayer:listen").also { it.acquire() }
        PlayerHolder.setFocusHandling(false)
        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) {
                tts?.language = Locale("ru", "RU")
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) { h.post { finishSpeech() } }
                    override fun onError(utteranceId: String?) { h.post { finishSpeech() } }
                })
                ttsReady = true
            }
        }
        h.postDelayed({ listen() }, 600)
    }

    private fun goForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CH, "Голосовое управление", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, VoiceService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CH) else Notification.Builder(this)
        val action = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_media_pause), "Выключить слушание", stop
        ).build()
        val n = b.setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Слушаю: «${Wake.name}»")
            .setContentText("Скажите имя и команду, например «${Wake.name}, следующая»")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(action)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
    }

    fun pauseListening() {
        paused = true
        rec?.cancel()
        listening = false
    }

    fun resumeListening() {
        paused = false
        scheduleListen(400)
    }

    private fun scheduleListen(delay: Long) { h.postDelayed({ listen() }, delay) }

    private fun listen() {
        if (paused || speaking || listening) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        if (rec == null) rec = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(rl) }
        listening = true
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, offline)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        try { rec?.startListening(i) } catch (e: Exception) { listening = false; scheduleListen(2000) }
    }

    private val rl = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
        override fun onPartialResults(partialResults: Bundle?) {}

        override fun onResults(results: Bundle?) {
            listening = false
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!text.isNullOrBlank()) handleSpeech(text)
            if (!paused) scheduleListen(250)
        }

        override fun onError(error: Int) {
            listening = false
            when (error) {
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> { rec?.destroy(); rec = null }
                12, 13 -> offline = false // офлайн-модель русского не установлена
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> { stopSelf(); return }
            }
            val quiet = error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
            if (!paused) scheduleListen(if (quiet) 300 else 2000)
        }
    }

    private fun handleSpeech(text: String) {
        val now = SystemClock.elapsedRealtime()
        val addressed = Wake.contains(text)
        if (!addressed && now > followUntil) return
        val cmd = Wake.strip(text)
        val reply: String
        if (cmd.isBlank()) {
            followUntil = now + 8000
            reply = "Слушаю"
        } else {
            followUntil = 0L
            reply = try { cmds.handle(cmd) } catch (e: Exception) { "Ошибка" }
        }
        speak(reply)
    }

    private fun speak(text: String) {
        val on = getSharedPreferences("vp", MODE_PRIVATE).getBoolean("speak", true)
        if (!on || !ttsReady) {
            if (text == "Слушаю") {
                try { ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80).startTone(ToneGenerator.TONE_PROP_ACK, 150) } catch (_: Exception) {}
            }
            return
        }
        speaking = true
        PlayerHolder.setDuck(0.3f)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u")
    }

    private fun finishSpeech() {
        speaking = false
        PlayerHolder.setDuck(1f)
        scheduleListen(200)
    }

    override fun onDestroy() {
        instance = null
        h.removeCallbacksAndMessages(null)
        try { rec?.destroy() } catch (_: Exception) {}
        tts?.shutdown()
        try { wl?.release() } catch (_: Exception) {}
        PlayerHolder.setDuck(1f)
        if (PlayerHolder.isReady()) PlayerHolder.setFocusHandling(true)
        super.onDestroy()
    }
}
