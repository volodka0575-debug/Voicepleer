package app.voiceplayer

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.database.ContentObserver
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import java.util.Locale

class MainActivity : Activity() {
    private val p get() = PlayerHolder.player
    private val h = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("vp", MODE_PRIVATE) }
    private lateinit var cmds: Commands

    private enum class Tab { HOME, LIB, EQ, PROFILE }
    private class Sub(val kind: String, val title: String, val key: String = "")
    private class NavItem(val tab: Tab, val icon: ImageView, val label: TextView, val bar: View)
    private class ChipDef(val text: String, val selected: Boolean, val onClick: () -> Unit)
    private class NowViews(
        val title: TextView, val artist: TextView, val seek: SeekBar, val pos: TextView, val dur: TextView,
        val play: ImageView, val cover: CoverView, val eq: EqBars, val sleep: TextView
    )
    private class RowHolder(
        val root: View, val cover: CoverView, val title: TextView, val artist: TextView,
        val heart: ImageView, val more: ImageView
    )

    private var tab = Tab.HOME
    private var sub: Sub? = null

    private lateinit var content: FrameLayout
    private lateinit var statusBar: TextView
    private lateinit var mini: LinearLayout
    private lateinit var miniTitle: TextView
    private lateinit var miniArtist: TextView
    private lateinit var miniCover: CoverView
    private lateinit var miniPlay: ImageView
    private val navItems = ArrayList<NavItem>()
    private val micViews = ArrayList<ImageView>()

    private var now: NowViews? = null
    private var sleepLabel: TextView? = null
    private var libEdit: EditText? = null
    private var homeScroll: ScrollView? = null
    private var plHeader: View? = null
    private var curAdapter: TrackAdapter? = null
    private var libQuery = ""
    private var byId: Map<Long, Track> = emptyMap()
    private var dragging = false
    private var suppress = false

    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var speakReplies = true
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var afterSpeech: (() -> Unit)? = null

    private val rescan = Runnable { loadLibrary() }
    private val hideStatus = Runnable { statusBar.visibility = View.GONE }
    private val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) {
            h.removeCallbacks(rescan)
            h.postDelayed(rescan, 2000)
        }
    }

    private val pl = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) = updateNow()
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            updateNow()
            curAdapter?.notifyDataSetChanged()
        }
        override fun onPlaybackStateChanged(playbackState: Int) = updateNow()
    }

    private val tick = object : Runnable {
        override fun run() {
            val n = now
            if (n != null) {
                val d = p.duration
                val pos = p.currentPosition
                if (d > 0 && !dragging) {
                    n.seek.max = d.toInt()
                    n.seek.progress = pos.toInt()
                    n.pos.text = Ru.fmt(pos)
                    n.dur.text = Ru.fmt(d)
                }
            }
            val r = PlayerHolder.sleepRemaining()
            val s = when {
                r >= 0 -> "😴 Таймер сна: " + Ru.fmt(r)
                PlayerHolder.trackEndMode -> "😴 Пауза в конце трека"
                else -> ""
            }
            sleepLabel?.text = if (s.isEmpty()) "Таймер не установлен" else s
            now?.sleep?.let {
                it.text = s
                it.visibility = if (s.isEmpty()) View.GONE else View.VISIBLE
            }
            h.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PlayerHolder.init(application)
        Store.init(this)
        Wake.load(this)
        cmds = Commands(applicationContext)
        speakReplies = prefs.getBoolean("speak", true)
        buildUi()
        render()
        p.addListener(pl)
        h.post(tick)

        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) {
                tts?.language = Locale("ru", "RU")
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) { runOnUiThread { finishSpeech() } }
                    override fun onError(utteranceId: String?) { runOnUiThread { finishSpeech() } }
                })
                ttsReady = true
            }
        }

        contentResolver.registerContentObserver(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, true, observer)

        val missing = needed().filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) loadLibrary() else requestPermissions(missing.toTypedArray(), 1)
    }

    private fun needed(): Array<String> {
        val l = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) {
            l.add(Manifest.permission.READ_MEDIA_AUDIO)
            l.add(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            l.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        return l.toTypedArray()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        loadLibrary()
    }

    override fun onStart() {
        super.onStart()
        try { startService(Intent(this, PlaybackService::class.java)) } catch (_: Exception) {}
        val always = prefs.getBoolean("always", false)
        if (always && VoiceService.instance == null &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        ) {
            try { VoiceService.start(this) } catch (_: Exception) {}
        }
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        p.removeListener(pl)
        contentResolver.unregisterContentObserver(observer)
        recognizer?.destroy()
        tts?.shutdown()
        PlayerHolder.setDuck(1f)
        VoiceService.instance?.resumeListening()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            sub != null -> { sub = null; render() }
            tab != Tab.HOME -> { tab = Tab.HOME; render() }
            else -> super.onBackPressed()
        }
    }

    // ================= каркас =================
    private fun buildUi() {
        val root = FrameLayout(this)
        root.addView(BgView(this), FrameLayout.LayoutParams(MATCH, MATCH))

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content = FrameLayout(this)
        col.addView(content, lp(MATCH, 0, 1f))

        statusBar = tv("", 14f, Color.WHITE).apply {
            background = glass(16)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            visibility = View.GONE
            setOnClickListener { visibility = View.GONE }
        }
        col.addView(statusBar, lp(MATCH, WRAP, l = dp(16), r = dp(16), b = dp(8)))

        buildMini()
        col.addView(mini, lp(MATCH, WRAP, l = dp(12), r = dp(12), b = dp(8)))
        col.addView(buildNav(), lp(MATCH, WRAP))

        root.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(root)
    }

    private fun buildMini() {
        mini = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = glass(24)
            setPadding(dp(10), dp(8), dp(10), dp(8))
            visibility = View.GONE
            setOnClickListener { sub = null; tab = Tab.HOME; render() }
        }
        miniCover = CoverView(this, 14)
        mini.addView(miniCover, lp(dp(46), dp(46)))
        val mid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        miniTitle = tv("", 16f, Color.WHITE, true).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        miniArtist = tv("", 13f, Pal.SUB).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        mid.addView(miniTitle)
        mid.addView(miniArtist)
        mini.addView(mid, lp(0, WRAP, 1f, l = dp(12), r = dp(8)))

        val prev = icon(R.drawable.ic_prev, Pal.ACCENT).apply {
            setPadding(dp(6), dp(6), dp(6), dp(6)); setOnClickListener { prevTrack() }
        }
        miniPlay = icon(R.drawable.ic_play, Pal.ACCENT).apply {
            setPadding(dp(4), dp(4), dp(4), dp(4)); setOnClickListener { togglePlay() }
        }
        val next = icon(R.drawable.ic_next, Pal.ACCENT).apply {
            setPadding(dp(6), dp(6), dp(6), dp(6)); setOnClickListener { nextTrack() }
        }
        mini.addView(prev, lp(dp(40), dp(40)))
        mini.addView(miniPlay, lp(dp(46), dp(46), l = dp(4), r = dp(4)))
        mini.addView(next, lp(dp(40), dp(40)))
    }

    private fun buildNav(): View {
        val r = dpf(26f)
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = GradientDrawable().apply {
                setColor(Pal.NAV)
                cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
                setStroke(dp(1), Pal.STROKE)
            }
            setPadding(dp(8), dp(8), dp(8), dp(6))
        }
        fun add(t: Tab, res: Int, text: String) {
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setOnClickListener { hideKb(); sub = null; tab = t; render() }
            }
            val ic = icon(res, Pal.SUB)
            val lb = tv(text, 12f, Pal.SUB)
            val ub = View(this).apply {
                background = GradientDrawable().apply { cornerRadius = dpf(2f); setColor(Pal.ACCENT) }
            }
            item.addView(ic, lp(dp(26), dp(26)))
            item.addView(lb, lp(WRAP, WRAP, t = dp(2)))
            item.addView(ub, lp(dp(30), dp(3), t = dp(4)))
            bar.addView(item, lp(0, WRAP, 1f))
            navItems.add(NavItem(t, ic, lb, ub))
        }
        add(Tab.HOME, R.drawable.ic_home, "Главная")
        add(Tab.LIB, R.drawable.ic_music, "Библиотека")
        add(Tab.EQ, R.drawable.ic_equalizer, "Эквалайзер")
        add(Tab.PROFILE, R.drawable.ic_person, "Профиль")
        return bar
    }

    private fun updateNav() {
        for (n in navItems) {
            val on = sub == null && n.tab == tab
            val c = if (on) Pal.ACCENT else Pal.SUB
            n.icon.imageTintList = ColorStateList.valueOf(c)
            n.label.setTextColor(if (on) Color.WHITE else Pal.SUB)
            n.bar.visibility = if (on) View.VISIBLE else View.INVISIBLE
        }
    }

    private fun render() {
        now = null; sleepLabel = null; libEdit = null; homeScroll = null; plHeader = null; curAdapter = null
        micViews.clear()
        content.removeAllViews()
        val s = sub
        val v = if (s != null) listPage(s) else when (tab) {
            Tab.HOME -> homePage()
            Tab.LIB -> libPage()
            Tab.EQ -> eqPage()
            Tab.PROFILE -> profilePage()
        }
        content.addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
        updateNav()
        updateNow()
        updateMic()
    }

    private fun openSub(s: Sub) { sub = s; render() }

    private fun openLibrary(focus: Boolean) {
        sub = null
        tab = Tab.LIB
        render()
        if (focus) {
            libEdit?.let { e ->
                e.requestFocus()
                h.postDelayed({
                    (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(e, 0)
                }, 150)
            }
        }
    }

    private fun hideKb() {
        val v = currentFocus ?: return
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(v.windowToken, 0)
        v.clearFocus()
    }

    // ================= общие куски =================
    private fun pageScroll(): Pair<ScrollView, LinearLayout> {
        val sc = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(16))
        }
        sc.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))
        return Pair(sc, col)
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = glass(24)
        setPadding(dp(18), dp(16), dp(18), dp(16))
    }

    private fun glassButton(res: Int, size: Int, action: () -> Unit): ImageView = icon(res, Color.WHITE).apply {
        background = pressable(14)
        setPadding(dp(11), dp(11), dp(11), dp(11))
        setOnClickListener { action() }
    }

    private fun micButton(): ImageView {
        val v = icon(R.drawable.ic_mic, Color.WHITE)
        v.setPadding(dp(9), dp(9), dp(9), dp(9))
        v.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Pal.GLOW) }
        v.setOnClickListener { toggleMic() }
        micViews.add(v)
        return v
    }

    private fun updateMic() {
        for (v in micViews) {
            (v.background as? GradientDrawable)?.setColor(if (listening) Pal.RED else Pal.GLOW)
        }
    }

    private fun styleSeek(sb: SeekBar) {
        sb.thumbTintList = ColorStateList.valueOf(Pal.ACCENT)
        sb.progressTintList = ColorStateList.valueOf(Pal.ACCENT)
        sb.progressBackgroundTintList = ColorStateList.valueOf(Color.parseColor("#44B388FF"))
        sb.setPadding(dp(10), 0, dp(10), 0)
    }

    private fun pretty(n: String): String = n.replaceFirstChar { it.uppercase() }

    private fun chipRow(defs: List<ChipDef>): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        defs.forEachIndexed { i, d ->
            val c = tv(d.text, 14f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER
                maxLines = 1
                background = GradientDrawable().apply {
                    cornerRadius = dpf(16f)
                    setColor(if (d.selected) Pal.DEEP else Pal.CHIP)
                    setStroke(dp(1), Pal.STROKE)
                }
                setOnClickListener { d.onClick() }
            }
            row.addView(c, lp(0, dp(40), 1f, l = if (i > 0) dp(8) else 0))
        }
        return row
    }

    // ================= данные =================
    private fun visibleTracks(): List<Track> {
        val ban = Store.banned()
        val l = MusicLibrary.tracks
        return if (ban.isEmpty()) l else l.filter { it.id.toString() !in ban }
    }

    private fun filterTracks(q: String): List<Track> {
        val all = visibleTracks()
        val qn = Ru.collapse(Ru.norm(q))
        if (qn.isEmpty()) return all
        val qt = Ru.collapse(Ru.translit(qn))
        val toks = qn.split(" ").filter { it.isNotBlank() }
        val tts2 = qt.split(" ").filter { it.isNotBlank() }
        return all.filter { t ->
            toks.all { k -> t.hay.contains(k) || t.hayTr.contains(k) } || tts2.all { k -> t.hay.contains(k) }
        }
    }

    private fun idsToTracks(ids: List<String>): List<Track> {
        val ban = Store.banned()
        return ids.mapNotNull { id ->
            val t = id.toLongOrNull()?.let { byId[it] }
            if (t == null || t.id.toString() in ban) null else t
        }
    }

    private fun subTracks(s: Sub): List<Track> = when (s.kind) {
        "fav" -> {
            val f = Store.favIds()
            visibleTracks().filter { it.id.toString() in f }
        }
        "recent" -> idsToTracks(Store.recentIds())
        "downloads" -> visibleTracks().filter { it.path.contains("/download", ignoreCase = true) }
        "playlist" -> idsToTracks(Store.playlistIds(s.key))
        else -> emptyList()
    }

    private fun playTracks(list: List<Track>, start: Int = 0) {
        if (list.isEmpty()) { setStatus("Здесь пока нет треков"); return }
        p.setMediaItems(list.map { it.item }, start, 0L)
        p.prepare()
        p.play()
    }

    private fun prevTrack() { p.seekToPreviousMediaItem(); p.play() }
    private fun nextTrack() { p.seekToNextMediaItem(); p.play() }
    private fun togglePlay() {
        if (p.isPlaying) p.pause()
        else if (p.mediaItemCount > 0) p.play()
        else voiceRun("включи музыку")
    }

    // ================= Главная =================
    private fun homePage(): View {
        val (sc, col) = pageScroll()
        homeScroll = sc

        // шапка
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(icon(R.drawable.ic_headphones, Pal.ACCENT), lp(dp(54), dp(54)))
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(tv("Музыка", 32f, Color.WHITE, true))
        titles.addView(tv("Слушай. Наслаждайся. ♡", 14f, Pal.SUB))
        head.addView(titles, lp(0, WRAP, 1f, l = dp(12)))
        head.addView(glassButton(R.drawable.ic_settings, 46) { sub = null; tab = Tab.PROFILE; render() }, lp(dp(46), dp(46)))
        col.addView(head, lp(MATCH, WRAP))

        // поиск
        val search = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = pressable(22)
            setPadding(dp(16), 0, dp(8), 0)
            setOnClickListener { openLibrary(true) }
        }
        search.addView(icon(R.drawable.ic_search, Pal.SUB), lp(dp(22), dp(22)))
        search.addView(tv("Поиск треков…", 16f, Pal.SUB), lp(0, WRAP, 1f, l = dp(12)))
        search.addView(micButton(), lp(dp(40), dp(40)))
        col.addView(search, lp(MATCH, dp(54), t = dp(18)))

        // быстрые кнопки
        fun quickBtn(res: Int, text: String, action: () -> Unit): View = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = pressable(18)
            setPadding(dp(4), dp(8), dp(4), dp(8))
            addView(icon(res, Color.WHITE), lp(dp(30), dp(30)))
            addView(tv(text, 12f, Color.WHITE).apply { gravity = Gravity.CENTER; maxLines = 1 }, lp(WRAP, WRAP, t = dp(8)))
            setOnClickListener { action() }
        }
        val quick = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        quick.addView(quickBtn(R.drawable.ic_heart_outline, "Избранное") { openSub(Sub("fav", "Избранное")) }, lp(0, dp(88), 1f))
        quick.addView(quickBtn(R.drawable.ic_clock, "Недавние") { openSub(Sub("recent", "Недавние")) }, lp(0, dp(88), 1f, l = dp(10)))
        quick.addView(quickBtn(R.drawable.ic_download, "Загрузки") { openSub(Sub("downloads", "Загрузки")) }, lp(0, dp(88), 1f, l = dp(10)))
        quick.addView(quickBtn(R.drawable.ic_playlist_add, "Плейлисты") {
            homeScroll?.post { homeScroll?.smoothScrollTo(0, plHeader?.top ?: 0) }
        }, lp(0, dp(88), 1f, l = dp(10)))
        col.addView(quick, lp(MATCH, WRAP, t = dp(16)))

        // сейчас играет
        val card = card()
        val hdr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        hdr.addView(tv("Сейчас играет", 19f, Color.WHITE, true), lp(0, WRAP, 1f))
        val all = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setOnClickListener { openLibrary(false) }
        }
        all.addView(tv("Все", 15f, Pal.SUB))
        all.addView(icon(R.drawable.ic_chevron, Pal.SUB), lp(dp(20), dp(20)))
        hdr.addView(all)
        card.addView(hdr, lp(MATCH, WRAP))

        val body = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val cover = CoverView(this, 18)
        body.addView(cover, lp(dp(98), dp(98)))
        val mid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = tv("", 21f, Color.WHITE, true).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        val artistRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val artist = tv("", 15f, Pal.SUB).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        val eq = EqBars(this)
        artistRow.addView(artist, lp(0, WRAP, 1f))
        artistRow.addView(eq, lp(dp(18), dp(14), l = dp(8)))
        mid.addView(title)
        mid.addView(artistRow)
        val seek = SeekBar(this)
        styleSeek(seek)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, prog: Int, fromUser: Boolean) {
                if (fromUser) now?.pos?.text = Ru.fmt(prog.toLong())
            }
            override fun onStartTrackingTouch(sb: SeekBar) { dragging = true }
            override fun onStopTrackingTouch(sb: SeekBar) { dragging = false; p.seekTo(sb.progress.toLong()) }
        })
        mid.addView(seek, lp(MATCH, dp(28), t = dp(4)))
        val times = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val pos = tv("0:00", 13f, Pal.SUB)
        val dur = tv("0:00", 13f, Pal.SUB).apply { gravity = Gravity.END }
        times.addView(pos, lp(0, WRAP, 1f, l = dp(10)))
        times.addView(dur, lp(0, WRAP, 1f, r = dp(10)))
        mid.addView(times, lp(MATCH, WRAP))
        val sleep = tv("", 12f, Pal.ACCENT).apply { visibility = View.GONE }
        mid.addView(sleep, lp(WRAP, WRAP, t = dp(2)))
        body.addView(mid, lp(0, WRAP, 1f, l = dp(14)))

        val playBtn = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Pal.GLOW)
                setStroke(dp(3), Pal.ACCENT)
            }
            setOnClickListener { togglePlay() }
        }
        val playIcon = icon(R.drawable.ic_pause, Color.WHITE)
        playBtn.addView(playIcon, FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER))
        body.addView(playBtn, lp(dp(64), dp(64), l = dp(10)))
        card.addView(body, lp(MATCH, WRAP, t = dp(12)))
        col.addView(card, lp(MATCH, WRAP, t = dp(16)))
        now = NowViews(title, artist, seek, pos, dur, playIcon, cover, eq, sleep)

        // плейлисты
        val ph = tv("Мои плейлисты", 20f, Color.WHITE, true)
        plHeader = ph
        col.addView(ph, lp(MATCH, WRAP, t = dp(22), b = dp(10)))

        val favCount = subTracks(Sub("fav", "")).size
        col.addView(
            plRow("Любимые треки", plTracks(favCount), R.drawable.ic_heart, 3,
                { openSub(Sub("fav", "Любимые треки")) },
                { a -> favMenu(a) }),
            lp(MATCH, WRAP, b = dp(10))
        )
        for (n in Store.playlistNames()) {
            val cnt = idsToTracks(Store.playlistIds(n)).size
            col.addView(
                plRow(pretty(n), plTracks(cnt), R.drawable.ic_playlist, n.hashCode(),
                    { openSub(Sub("playlist", pretty(n), n)) },
                    { a -> playlistMenu(a, n) }),
                lp(MATCH, WRAP, b = dp(10))
            )
        }
        col.addView(
            plRow("Новый плейлист", "Создать подборку", R.drawable.ic_add, 1,
                { promptNewPlaylist { render() } }, null),
            lp(MATCH, WRAP, b = dp(4))
        )
        return sc
    }

    private fun plRow(
        title: String, subtitle: String, iconRes: Int, seed: Int,
        onClick: () -> Unit, onMore: ((View) -> Unit)?
    ): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = pressable(18)
            setPadding(dp(10), dp(8), dp(6), dp(8))
            setOnClickListener { onClick() }
        }
        val cv = CoverView(this, 14)
        cv.bindSeed(seed, iconRes)
        row.addView(cv, lp(dp(56), dp(56)))
        val mid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        mid.addView(tv(title, 17f, Color.WHITE, true).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
        mid.addView(tv(subtitle, 13f, Pal.SUB))
        row.addView(mid, lp(0, WRAP, 1f, l = dp(14)))
        if (onMore != null) {
            val more = icon(R.drawable.ic_more, Pal.SUB).apply {
                setPadding(dp(10), dp(10), dp(10), dp(10))
                setOnClickListener { onMore(it) }
            }
            row.addView(more, lp(dp(44), dp(44)))
        }
        return row
    }

    private fun favMenu(anchor: View) {
        val m = PopupMenu(this, anchor)
        m.menu.add(0, 1, 0, "Включить")
        m.setOnMenuItemClickListener {
            playTracks(subTracks(Sub("fav", "")))
            true
        }
        m.show()
    }

    private fun playlistMenu(anchor: View, name: String) {
        val m = PopupMenu(this, anchor)
        m.menu.add(0, 1, 0, "Включить")
        m.menu.add(0, 2, 1, "Удалить")
        m.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> playTracks(idsToTracks(Store.playlistIds(name)))
                2 -> confirmDelete(name)
            }
            true
        }
        m.show()
    }

    private fun confirmDelete(name: String) {
        AlertDialog.Builder(this)
            .setTitle("Удалить плейлист?")
            .setMessage(pretty(name))
            .setPositiveButton("Удалить") { _, _ -> Store.deletePlaylist(name); sub = null; render() }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun promptNewPlaylist(onDone: (String) -> Unit) {
        val et = EditText(this).apply {
            hint = "Название"
            setSingleLine()
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
        }
        val box = FrameLayout(this).apply {
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(et, FrameLayout.LayoutParams(MATCH, WRAP))
        }
        AlertDialog.Builder(this)
            .setTitle("Новый плейлист")
            .setView(box)
            .setPositiveButton("Создать") { _, _ ->
                val n = Ru.norm(et.text.toString())
                if (n.isEmpty()) {
                    setStatus("Введите название плейлиста")
                } else {
                    if (!Store.playlistNames().contains(n)) Store.savePlaylist(n, emptyList())
                    onDone(n)
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun addToPlaylist(name: String, t: Track) {
        val ids = Store.playlistIds(name).toMutableList()
        val k = t.id.toString()
        if (!ids.contains(k)) ids.add(k)
        Store.savePlaylist(name, ids)
        setStatus("Добавлено в «${pretty(name)}»")
    }

    private fun addToPlaylistDialog(t: Track) {
        val names = Store.playlistNames()
        val labels = names.map { pretty(it) } + "＋ Новый плейлист"
        AlertDialog.Builder(this)
            .setTitle("В плейлист")
            .setItems(labels.toTypedArray()) { _, i ->
                if (i < names.size) addToPlaylist(names[i], t)
                else promptNewPlaylist { n -> addToPlaylist(n, t) }
            }
            .show()
    }

    private fun trackMenu(anchor: View, t: Track, plName: String?) {
        val m = PopupMenu(this, anchor)
        m.menu.add(0, 1, 0, if (Store.isFav(t.id)) "Убрать из избранного" else "В избранное")
        m.menu.add(0, 2, 1, "Добавить в плейлист…")
        m.menu.add(0, 3, 2, "Играть следующим")
        if (plName != null) m.menu.add(0, 4, 3, "Убрать из плейлиста")
        m.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> { Store.toggleFav(t.id); curAdapter?.reload() }
                2 -> addToPlaylistDialog(t)
                3 -> {
                    if (p.mediaItemCount == 0) playTracks(listOf(t))
                    else {
                        p.addMediaItem(p.currentMediaItemIndex + 1, t.item)
                        setStatus("Сыграю следующим: ${t.title}")
                    }
                }
                4 -> {
                    if (plName != null) {
                        val ids = Store.playlistIds(plName).toMutableList()
                        ids.remove(t.id.toString())
                        Store.savePlaylist(plName, ids)
                        curAdapter?.reload()
                    }
                }
            }
            true
        }
        m.show()
    }

    // ================= списки треков =================
    private inner class TrackAdapter(
        private val supplier: () -> List<Track>,
        private val plName: String?,
        private val onChange: (Int) -> Unit
    ) : BaseAdapter() {
        var items: List<Track> = supplier()

        init { onChange(items.size) }

        fun reload() {
            items = supplier()
            notifyDataSetChanged()
            onChange(items.size)
        }

        override fun getCount(): Int = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int): Long = items[position].id

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val hd = (convertView?.tag as? RowHolder) ?: newRow()
            val t = items[position]
            hd.title.text = t.title
            hd.artist.text = t.artist
            hd.cover.bindSeed(t.id.toInt(), R.drawable.ic_music)
            val playing = p.currentMediaItem?.mediaId == t.id.toString()
            hd.title.setTextColor(if (playing) Pal.ACCENT else Color.WHITE)
            val fav = Store.isFav(t.id)
            hd.heart.setImageResource(if (fav) R.drawable.ic_heart else R.drawable.ic_heart_outline)
            hd.heart.imageTintList = ColorStateList.valueOf(if (fav) Pal.ACCENT else Pal.SUB)
            hd.heart.setOnClickListener { Store.toggleFav(t.id); reload() }
            hd.more.setOnClickListener { trackMenu(it, t, plName) }
            return hd.root
        }
    }

    private fun newRow(): RowHolder {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = glass(16)
            setPadding(dp(10), dp(8), dp(2), dp(8))
        }
        val cover = CoverView(this, 12)
        root.addView(cover, lp(dp(48), dp(48)))
        val mid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = tv("", 16f, Color.WHITE, true).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        val artist = tv("", 13f, Pal.SUB).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        mid.addView(title)
        mid.addView(artist)
        root.addView(mid, lp(0, WRAP, 1f, l = dp(12)))
        val heart = icon(R.drawable.ic_heart_outline, Pal.SUB).apply { setPadding(dp(10), dp(10), dp(10), dp(10)) }
        val more = icon(R.drawable.ic_more, Pal.SUB).apply { setPadding(dp(10), dp(10), dp(10), dp(10)) }
        root.addView(heart, lp(dp(42), dp(42)))
        root.addView(more, lp(dp(42), dp(42)))
        val holder = RowHolder(root, cover, title, artist, heart, more)
        root.tag = holder
        return holder
    }

    private fun listWithEmpty(ad: TrackAdapter, emptyText: String): View {
        val fl = FrameLayout(this)
        val list = ListView(this).apply {
            adapter = ad
            divider = ColorDrawable(Color.TRANSPARENT)
            dividerHeight = dp(8)
            selector = ColorDrawable(Color.TRANSPARENT)
            setCacheColorHint(Color.TRANSPARENT)
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
            clipToPadding = false
            setPadding(0, dp(8), 0, dp(8))
            setOnItemClickListener { _, _, pos, _ -> playTracks(ad.items, pos) }
        }
        val empty = tv(emptyText, 15f, Pal.SUB).apply {
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
        }
        fl.addView(list, FrameLayout.LayoutParams(MATCH, MATCH))
        fl.addView(empty, FrameLayout.LayoutParams(MATCH, MATCH))
        list.emptyView = empty
        return fl
    }

    // ================= Библиотека =================
    private fun libPage(): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), 0)
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(tv("Библиотека", 30f, Color.WHITE, true), lp(0, WRAP, 1f))
        val count = tv("", 14f, Pal.SUB)
        head.addView(count)
        col.addView(head, lp(MATCH, WRAP))

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = glass(22)
            setPadding(dp(16), 0, dp(8), 0)
        }
        bar.addView(icon(R.drawable.ic_search, Pal.SUB), lp(dp(22), dp(22)))
        val et = EditText(this).apply {
            setText(libQuery)
            hint = "Поиск треков…"
            setHintTextColor(Pal.SUB)
            setTextColor(Color.WHITE)
            textSize = 16f
            setSingleLine()
            setBackgroundColor(Color.TRANSPARENT)
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setOnEditorActionListener { _, _, _ -> hideKb(); true }
        }
        libEdit = et
        bar.addView(et, lp(0, MATCH, 1f, l = dp(10)))
        bar.addView(micButton(), lp(dp(40), dp(40)))
        col.addView(bar, lp(MATCH, dp(54), t = dp(14)))

        val ad = TrackAdapter({ filterTracks(libQuery) }, null) { n -> count.text = plTracks(n) }
        curAdapter = ad
        et.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                libQuery = s?.toString() ?: ""
                ad.reload()
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
        col.addView(listWithEmpty(ad, "Ничего не найдено"), lp(MATCH, 0, 1f, t = dp(6)))
        return col
    }

    // ================= Подборка (избранное, недавние, загрузки, плейлист) =================
    private fun listPage(s: Sub): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), 0)
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(glassButton(R.drawable.ic_back, 44) { sub = null; render() }, lp(dp(44), dp(44)))
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(tv(s.title, 24f, Color.WHITE, true).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
        val count = tv("", 13f, Pal.SUB)
        titles.addView(count)
        head.addView(titles, lp(0, WRAP, 1f, l = dp(12)))

        val supplier: () -> List<Track> = { subTracks(s) }
        val playPill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply { cornerRadius = dpf(22f); setColor(Pal.DEEP) }
            setPadding(dp(12), 0, dp(16), 0)
            setOnClickListener { playTracks(supplier()) }
        }
        playPill.addView(icon(R.drawable.ic_play, Color.WHITE), lp(dp(20), dp(20)))
        playPill.addView(tv("Играть", 14f, Color.WHITE, true), lp(WRAP, WRAP, l = dp(4)))
        head.addView(playPill, lp(WRAP, dp(40)))
        if (s.kind == "playlist") {
            val more = icon(R.drawable.ic_more, Color.WHITE).apply {
                setPadding(dp(8), dp(8), dp(8), dp(8))
                setOnClickListener { a ->
                    val m = PopupMenu(this@MainActivity, a)
                    m.menu.add(0, 1, 0, "Удалить плейлист")
                    m.setOnMenuItemClickListener { confirmDelete(s.key); true }
                    m.show()
                }
            }
            head.addView(more, lp(dp(40), dp(40), l = dp(4)))
        }
        col.addView(head, lp(MATCH, WRAP))

        val emptyText = when (s.kind) {
            "fav" -> "Пока пусто. Нажмите ♡ у трека, чтобы добавить его в избранное"
            "recent" -> "Здесь появятся треки, которые вы слушали"
            "downloads" -> "В папке «Загрузки» нет музыки"
            else -> "Плейлист пуст. Добавьте треки через ⋮ в библиотеке"
        }
        val ad = TrackAdapter(supplier, if (s.kind == "playlist") s.key else null) { n -> count.text = plTracks(n) }
        curAdapter = ad
        col.addView(listWithEmpty(ad, emptyText), lp(MATCH, 0, 1f, t = dp(6)))
        return col
    }

    // ================= Эквалайзер =================
    private fun eqPage(): View {
        val (sc, col) = pageScroll()
        col.addView(tv("Эквалайзер", 30f, Color.WHITE, true), lp(MATCH, WRAP, b = dp(14)))

        val bass = card()
        val bh = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        bh.addView(tv("Усиление баса", 18f, Color.WHITE, true), lp(0, WRAP, 1f))
        val bv = tv("${PlayerHolder.bassStrength / 10}%", 15f, Pal.ACCENT, true)
        bh.addView(bv)
        bass.addView(bh, lp(MATCH, WRAP))
        val sb = SeekBar(this)
        styleSeek(sb)
        sb.max = 1000
        sb.progress = PlayerHolder.bassStrength
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, prog: Int, fromUser: Boolean) {
                if (fromUser) { PlayerHolder.setBass(prog); bv.text = "${prog / 10}%" }
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        bass.addView(sb, lp(MATCH, dp(36), t = dp(8)))
        col.addView(bass, lp(MATCH, WRAP, b = dp(14)))

        val speed = card()
        speed.addView(tv("Скорость", 18f, Color.WHITE, true), lp(MATCH, WRAP, b = dp(12)))
        val cur = p.playbackParameters.speed
        val speeds = listOf(0.75f, 1f, 1.25f, 1.5f, 2f)
        speed.addView(chipRow(speeds.map { f ->
            ChipDef(if (f == 1f) "1×" else "$f×".replace(".0×", "×"), Math.abs(cur - f) < 0.01f) {
                p.setPlaybackSpeed(f); render()
            }
        }), lp(MATCH, WRAP))
        col.addView(speed, lp(MATCH, WRAP, b = dp(14)))

        val sleep = card()
        sleep.addView(tv("Таймер сна", 18f, Color.WHITE, true), lp(MATCH, WRAP))
        val sl = tv("", 14f, Pal.ACCENT)
        sleepLabel = sl
        sleep.addView(sl, lp(MATCH, WRAP, t = dp(4), b = dp(12)))
        val off = PlayerHolder.sleepRemaining() < 0 && !PlayerHolder.trackEndMode
        sleep.addView(chipRow(listOf(
            ChipDef("Выкл", off) { PlayerHolder.cancelSleep(); render() },
            ChipDef("15 мин", false) { PlayerHolder.startSleep(15 * 60_000L); render() },
            ChipDef("30 мин", false) { PlayerHolder.startSleep(30 * 60_000L); render() },
            ChipDef("60 мин", false) { PlayerHolder.startSleep(60 * 60_000L); render() }
        )), lp(MATCH, WRAP))
        sleep.addView(chipRow(listOf(
            ChipDef("До конца трека", PlayerHolder.trackEndMode) { PlayerHolder.sleepAtTrackEnd(); render() }
        )), lp(MATCH, WRAP, t = dp(8)))
        col.addView(sleep, lp(MATCH, WRAP))
        return sc
    }

    // ================= Профиль =================
    private fun profilePage(): View {
        val (sc, col) = pageScroll()

        val top = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        val avatar = icon(R.drawable.ic_person, Color.WHITE).apply {
            setPadding(dp(20), dp(20), dp(20), dp(20))
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Pal.DEEP)
                setStroke(dp(3), Pal.ACCENT)
            }
        }
        top.addView(avatar, lp(dp(92), dp(92)))
        top.addView(tv(pretty(Wake.name), 24f, Color.WHITE, true), lp(WRAP, WRAP, t = dp(10)))
        top.addView(tv("Голосовой плеер", 14f, Pal.SUB))
        col.addView(top, lp(MATCH, WRAP, b = dp(16)))

        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun stat(value: Int, label: String, first: Boolean) {
            val c = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                background = glass(18)
                setPadding(dp(6), dp(12), dp(6), dp(12))
            }
            c.addView(tv(value.toString(), 22f, Color.WHITE, true))
            c.addView(tv(label, 12f, Pal.SUB))
            stats.addView(c, lp(0, WRAP, 1f, l = if (first) 0 else dp(10)))
        }
        stat(visibleTracks().size, "треков", true)
        stat(subTracks(Sub("fav", "")).size, "в избранном", false)
        stat(Store.playlistNames().size, "плейлистов", false)
        col.addView(stats, lp(MATCH, WRAP, b = dp(14)))

        val voice = card()
        voice.addView(tv("Голос", 18f, Color.WHITE, true), lp(MATCH, WRAP, b = dp(10)))
        voice.addView(tv("Имя плеера", 13f, Pal.SUB))
        val nameRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val etName = EditText(this).apply {
            setText(Wake.name)
            hint = "Имя плеера"
            setSingleLine()
            setTextColor(Color.WHITE)
            setHintTextColor(Pal.SUB)
        }
        val btnName = tv("Сохранить", 14f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            background = GradientDrawable().apply { cornerRadius = dpf(16f); setColor(Pal.DEEP) }
            setPadding(dp(14), 0, dp(14), 0)
            setOnClickListener {
                val n = etName.text.toString().trim()
                if (n.length < 3) setStatus("Имя слишком короткое")
                else {
                    Wake.set(this@MainActivity, n)
                    etName.setText(Wake.name)
                    setStatus("Теперь я откликаюсь на «${Wake.name}». Можно сказать: «${Wake.name}, следующая»")
                }
            }
        }
        nameRow.addView(etName, lp(0, WRAP, 1f))
        nameRow.addView(btnName, lp(WRAP, dp(40), l = dp(8)))
        voice.addView(nameRow, lp(MATCH, WRAP, b = dp(6)))

        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        fun switchRow(text: String, checked: Boolean, onChange: (Switch, Boolean) -> Unit) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            row.addView(tv(text, 15f, Color.WHITE), lp(0, WRAP, 1f, r = dp(8)))
            val sw = Switch(this)
            sw.isChecked = checked
            sw.thumbTintList = ColorStateList(states, intArrayOf(Pal.ACCENT, Color.parseColor("#9E92C8")))
            sw.trackTintList = ColorStateList(states, intArrayOf(Color.parseColor("#66B388FF"), Color.parseColor("#44FFFFFF")))
            sw.setOnCheckedChangeListener { btn, on -> onChange(btn as Switch, on) }
            row.addView(sw)
            voice.addView(row, lp(MATCH, WRAP, t = dp(8)))
        }
        switchRow("Слушать в фоне (при закрытом приложении и экране)", prefs.getBoolean("always", false)) { sw, on ->
            if (!suppress) {
                if (on) {
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2)
                        suppress = true; sw.isChecked = false; suppress = false
                    } else {
                        prefs.edit().putBoolean("always", true).apply()
                        VoiceService.start(this@MainActivity)
                        setStatus("Слушаю в фоне. Скажите: «${Wake.name}, следующая»")
                    }
                } else {
                    prefs.edit().putBoolean("always", false).apply()
                    VoiceService.stop(this@MainActivity)
                    setStatus("Фоновое слушание выключено")
                }
            }
        }
        switchRow("Озвучивать ответы", speakReplies) { _, on ->
            speakReplies = on
            prefs.edit().putBoolean("speak", on).apply()
        }
        col.addView(voice, lp(MATCH, WRAP, b = dp(14)))

        val help = card()
        help.addView(tv("Что я умею", 18f, Color.WHITE, true), lp(MATCH, WRAP, b = dp(8)))
        help.addView(tv(Commands.HELP, 14f, Pal.SUB))
        col.addView(help, lp(MATCH, WRAP))
        return sc
    }

    // ================= состояние плеера =================
    private fun updateNow() {
        val item = p.currentMediaItem
        val m = item?.mediaMetadata
        val t = item?.mediaId?.toLongOrNull()?.let { byId[it] }
        val title = m?.title?.toString() ?: "Ничего не играет"
        val artist = m?.artist?.toString() ?: "Выберите трек или скажите: «включи …»"
        val playing = p.isPlaying
        val icRes = if (playing) R.drawable.ic_pause else R.drawable.ic_play

        mini.visibility = if (item != null) View.VISIBLE else View.GONE
        miniTitle.text = title
        miniArtist.text = artist
        miniPlay.setImageResource(icRes)
        miniCover.bindTrack(t)

        now?.let {
            it.title.text = title
            it.artist.text = artist
            it.play.setImageResource(icRes)
            it.cover.bindTrack(t)
            it.eq.setActive(playing)
        }
    }

    private fun setStatus(s: String) {
        statusBar.text = s
        statusBar.visibility = View.VISIBLE
        h.removeCallbacks(hideStatus)
        h.postDelayed(hideStatus, 9000)
    }

    // ================= библиотека =================
    private fun loadLibrary() {
        Thread {
            MusicLibrary.scan(this)
            runOnUiThread {
                byId = MusicLibrary.tracks.associateBy { it.id }
                val ad = curAdapter
                if (ad != null) ad.reload() else render()
                if (visibleTracks().isEmpty()) setStatus("Музыка не найдена. Разрешите доступ к аудио.")
            }
        }.start()
    }

    // ================= ручной микрофон (без слова активации) =================
    private fun toggleMic() {
        if (listening) { recognizer?.cancel(); endManual(true); return }
        startListening()
    }

    private fun endManual(resumeService: Boolean) {
        listening = false
        PlayerHolder.setDuck(1f)
        updateMic()
        if (resumeService) VoiceService.instance?.resumeListening()
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            setStatus("Нет сервиса распознавания речи. Установите/включите приложение Google."); return
        }
        if (listening) return
        VoiceService.instance?.pauseListening()
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(rl) }
        }
        listening = true
        updateMic()
        PlayerHolder.setDuck(0.2f)
        setStatus("Слушаю…")
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        recognizer?.startListening(i)
    }

    private val rl = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
        override fun onPartialResults(b: Bundle?) {
            val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!t.isNullOrBlank()) setStatus("🗣 $t…")
        }
        override fun onResults(r: Bundle?) {
            val text = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (text.isNullOrBlank()) { endManual(true); return }
            endManual(false)
            voiceRun(text)
        }
        override fun onError(error: Int) {
            if (error == SpeechRecognizer.ERROR_CLIENT) { endManual(true); return }
            if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) { recognizer?.destroy(); recognizer = null }
            endManual(true)
            setStatus(
                when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Не расслышал, попробуйте ещё раз"
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Нет доступа к микрофону"
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Для распознавания речи нужен интернет"
                    else -> "Ошибка распознавания ($error)"
                }
            )
        }
    }

    private fun voiceRun(text: String) {
        val reply = try { cmds.handle(text) } catch (e: Exception) { "Ошибка: ${e.message}" }
        setStatus("🗣 $text\n➡ $reply")
        updateNow()
        curAdapter?.reload()
        speak(reply) { VoiceService.instance?.resumeListening() }
    }

    private fun speak(text: String, done: () -> Unit) {
        if (!speakReplies || !ttsReady) { done(); return }
        afterSpeech = done
        PlayerHolder.setDuck(0.3f)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u")
    }

    private fun finishSpeech() {
        PlayerHolder.setDuck(1f)
        val a = afterSpeech
        afterSpeech = null
        a?.invoke()
    }
}
