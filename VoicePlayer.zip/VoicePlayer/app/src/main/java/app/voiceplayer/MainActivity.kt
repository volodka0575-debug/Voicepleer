package app.voiceplayer

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.database.ContentObserver
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.TextUtils
import android.view.Gravity
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.SeekBar
import android.widget.TextView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import java.util.Locale

class MainActivity : Activity() {
    private val p get() = PlayerHolder.player
    private val h = Handler(Looper.getMainLooper())
    private lateinit var cmds: Commands

    private lateinit var tvTitle: TextView
    private lateinit var tvArtist: TextView
    private lateinit var tvPos: TextView
    private lateinit var tvDur: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvSleep: TextView
    private lateinit var seek: SeekBar
    private lateinit var btnPlay: Button
    private lateinit var btnMic: Button
    private lateinit var listView: ListView
    private lateinit var lvAdapter: ArrayAdapter<String>
    private var shown: List<Track> = emptyList()
    private var dragging = false

    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var manual = false
    private var continuous = false
    private var speakReplies = true
    private var speaking = false
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var afterSpeech: (() -> Unit)? = null

    private val rescan = Runnable { loadLibrary() }
    private val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) {
            h.removeCallbacks(rescan)
            h.postDelayed(rescan, 2000)
        }
    }

    private val pl = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) = updateNow()
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = updateNow()
        override fun onPlaybackStateChanged(playbackState: Int) = updateNow()
    }

    private val tick = object : Runnable {
        override fun run() {
            val d = p.duration
            val pos = p.currentPosition
            if (d > 0 && !dragging) {
                seek.max = d.toInt()
                seek.progress = pos.toInt()
                tvPos.text = Ru.fmt(pos)
                tvDur.text = Ru.fmt(d)
            }
            val r = PlayerHolder.sleepRemaining()
            tvSleep.text = when {
                r >= 0 -> "😴 Таймер сна: " + Ru.fmt(r)
                PlayerHolder.trackEndMode -> "😴 Пауза в конце трека"
                else -> ""
            }
            h.postDelayed(this, 500)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PlayerHolder.init(application)
        cmds = Commands(this)
        buildUi()
        p.addListener(pl)
        updateNow()
        h.post(tick)

        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) {
                tts?.language = Locale("ru", "RU")
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) { runOnUiThread { finishSpeech() } }
                    override fun onError(utteranceId: String?) { runOnUiThread { finishSpeech() } }
                })
                ttsReady = true
            }
        }

        contentResolver.registerContentObserver(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, true, observer)

        val missing = needed().filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) loadLibrary() else requestPermissions(missing.toTypedArray(), 1)
    }

    private fun needed(): Array<String> {
        val l = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) {
            l.add(Manifest.permission.READ_MEDIA_AUDIO)
            l.add(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            l.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        return l.toTypedArray()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        loadLibrary()
    }

    override fun onStart() {
        super.onStart()
        try { startService(Intent(this, PlaybackService::class.java)) } catch (_: Exception) {}
        if (continuous) h.postDelayed({ if (!listening) startListening(false) }, 500)
    }

    override fun onStop() {
        super.onStop()
        if (continuous) {
            h.removeCallbacksAndMessages(null)
            h.post(tick)
            recognizer?.cancel()
            listening = false
            PlayerHolder.setDuck(1f)
            btnMic.text = "🎤"
            setStatus("Постоянное слушание работает только при открытом приложении")
        }
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        p.removeListener(pl)
        contentResolver.unregisterContentObserver(observer)
        recognizer?.destroy()
        tts?.shutdown()
        PlayerHolder.setDuck(1f)
        super.onDestroy()
    }

    // ---------- UI ----------
    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#121212"))
            setPadding(dp(16), dp(32), dp(16), dp(8))
        }
        tvTitle = TextView(this).apply {
            textSize = 22f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD)
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        }
        tvArtist = TextView(this).apply {
            textSize = 15f; setTextColor(Color.parseColor("#B0B0B0")); maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        seek = SeekBar(this).apply {
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, prog: Int, fromUser: Boolean) {
                    if (fromUser) tvPos.text = Ru.fmt(prog.toLong())
                }
                override fun onStartTrackingTouch(sb: SeekBar) { dragging = true }
                override fun onStopTrackingTouch(sb: SeekBar) { dragging = false; p.seekTo(sb.progress.toLong()) }
            })
        }
        tvPos = TextView(this).apply { text = "0:00"; setTextColor(Color.GRAY) }
        tvDur = TextView(this).apply { text = "0:00"; setTextColor(Color.GRAY); gravity = Gravity.END }
        val times = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(tvPos, LinearLayout.LayoutParams(0, -2, 1f))
            addView(tvDur, LinearLayout.LayoutParams(0, -2, 1f))
        }
        val prev = ctl("⏮") { p.seekToPreviousMediaItem(); p.play() }
        btnPlay = ctl("▶") { if (p.isPlaying) p.pause() else if (p.mediaItemCount > 0) p.play() else voiceRun("включи музыку") }
        val next = ctl("⏭") { p.seekToNextMediaItem(); p.play() }
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(prev); addView(btnPlay); addView(next)
        }
        btnMic = Button(this).apply {
            text = "🎤"; textSize = 34f
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#E53935")) }
            setOnClickListener { toggleMic() }
        }
        tvStatus = TextView(this).apply {
            textSize = 14f; setTextColor(Color.parseColor("#CCCCCC")); gravity = Gravity.CENTER
            minLines = 2; text = "Нажмите 🎤 и скажите: «включи …», «таймер сна на 20 минут», «перемотай на 1:30», «что ты умеешь»"
        }
        tvSleep = TextView(this).apply { textSize = 14f; setTextColor(Color.parseColor("#90CAF9")); gravity = Gravity.CENTER }
        val cbCont = CheckBox(this).apply {
            text = "Слушать постоянно (команды со словом «плеер»)"
            setTextColor(Color.WHITE)
            setOnCheckedChangeListener { _, on ->
                continuous = on
                if (on) startListening(false) else {
                    recognizer?.cancel(); listening = false
                    PlayerHolder.setDuck(1f); btnMic.text = "🎤"
                }
            }
        }
        val cbSpeak = CheckBox(this).apply {
            text = "Озвучивать ответы"; isChecked = true; setTextColor(Color.WHITE)
            setOnCheckedChangeListener { _, on -> speakReplies = on }
        }
        lvAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf<String>())
        listView = ListView(this).apply {
            adapter = lvAdapter
            setOnItemClickListener { _, _, pos, _ ->
                p.setMediaItems(shown.map { it.item }, pos, 0L)
                p.prepare(); p.play()
            }
        }
        root.addView(tvTitle)
        root.addView(tvArtist)
        root.addView(seek)
        root.addView(times)
        root.addView(controls, LinearLayout.LayoutParams(-1, -2))
        root.addView(btnMic, LinearLayout.LayoutParams(dp(96), dp(96)).apply {
            gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(10); bottomMargin = dp(6)
        })
        root.addView(tvStatus, LinearLayout.LayoutParams(-1, -2))
        root.addView(tvSleep, LinearLayout.LayoutParams(-1, -2))
        root.addView(cbCont)
        root.addView(cbSpeak)
        root.addView(listView, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun ctl(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label; textSize = 24f
        layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        setOnClickListener { onClick(); updateNow() }
    }

    private fun updateNow() {
        val m = p.currentMediaItem?.mediaMetadata
        tvTitle.text = m?.title ?: "Голосовой плеер"
        tvArtist.text = m?.artist ?: "Музыка с устройства"
        btnPlay.text = if (p.isPlaying) "⏸" else "▶"
    }

    private fun setStatus(s: String) { tvStatus.text = s }

    // ---------- библиотека ----------
    private fun loadLibrary() {
        Thread {
            MusicLibrary.scan(this)
            runOnUiThread {
                shown = MusicLibrary.tracks
                lvAdapter.clear()
                lvAdapter.addAll(shown.map { it.label })
                if (shown.isEmpty()) setStatus("Музыка не найдена. Разрешите доступ к аудио.")
            }
        }.start()
    }

    // ---------- голос ----------
    private fun toggleMic() {
        if (listening) {
            if (continuous) { manual = true; setStatus("Говорите команду…") }
            else { recognizer?.cancel(); listening = false; PlayerHolder.setDuck(1f); btnMic.text = "🎤" }
            return
        }
        startListening(true)
    }

    private fun startListening(isManual: Boolean) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            setStatus("Нет сервиса распознавания речи. Установите/включите приложение Google."); return
        }
        if (listening || speaking) return
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(rl) }
        }
        manual = isManual
        listening = true
        btnMic.text = "🔴"
        PlayerHolder.setDuck(0.2f)
        if (isManual || !continuous) setStatus("Слушаю…")
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        recognizer?.startListening(i)
    }

    private fun restartIfContinuous(delay: Long) {
        h.postDelayed({ if (continuous && !listening && !speaking) startListening(false) }, delay)
    }

    private val rl = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
        override fun onPartialResults(b: Bundle?) {
            val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!t.isNullOrBlank() && (manual || !continuous)) setStatus("🗣 $t…")
        }
        override fun onResults(r: Bundle?) {
            listening = false
            PlayerHolder.setDuck(1f)
            btnMic.text = "🎤"
            val text = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (text.isNullOrBlank()) { restartIfContinuous(300); return }
            onHeard(text)
        }
        override fun onError(error: Int) {
            listening = false
            PlayerHolder.setDuck(1f)
            btnMic.text = "🎤"
            if (error == SpeechRecognizer.ERROR_CLIENT) return
            if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) { recognizer?.destroy(); recognizer = null }
            if (continuous) {
                val quiet = error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                restartIfContinuous(if (quiet) 300 else 1500)
                return
            }
            setStatus(
                when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Не расслышал, попробуйте ещё раз"
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Нет доступа к микрофону"
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Для распознавания речи нужен интернет"
                    else -> "Ошибка распознавания ($error)"
                }
            )
        }
    }

    private fun onHeard(text: String) {
        val n = Ru.norm(text)
        val wasManual = manual
        manual = false
        if (continuous && !wasManual && !n.contains("плеер") && !n.contains("player")) {
            restartIfContinuous(200); return
        }
        voiceRun(text)
    }

    private fun voiceRun(text: String) {
        val reply = try { cmds.handle(text) } catch (e: Exception) { "Ошибка: ${e.message}" }
        setStatus("🗣 $text\n➡ $reply")
        updateNow()
        speak(reply) { restartIfContinuous(200) }
    }

    private fun speak(text: String, done: () -> Unit) {
        if (!speakReplies || !ttsReady) { done(); return }
        afterSpeech = done
        speaking = true
        PlayerHolder.setDuck(0.3f)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u")
    }

    private fun finishSpeech() {
        speaking = false
        PlayerHolder.setDuck(1f)
        val a = afterSpeech
        afterSpeech = null
        a?.invoke()
    }
}
