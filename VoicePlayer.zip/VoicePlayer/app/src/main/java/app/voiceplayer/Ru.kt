package app.voiceplayer

/** Разбор русской речи: нормализация, числа словами, длительности, транслит. */
object Ru {
    private val NUM = mapOf(
        "ноль" to 0, "один" to 1, "одну" to 1, "одна" to 1, "одно" to 1, "два" to 2, "две" to 2,
        "три" to 3, "четыре" to 4, "пять" to 5, "шесть" to 6, "семь" to 7, "восемь" to 8,
        "девять" to 9, "десять" to 10, "одиннадцать" to 11, "двенадцать" to 12,
        "тринадцать" to 13, "четырнадцать" to 14, "пятнадцать" to 15, "шестнадцать" to 16,
        "семнадцать" to 17, "восемнадцать" to 18, "девятнадцать" to 19, "двадцать" to 20,
        "тридцать" to 30, "сорок" to 40, "пятьдесят" to 50, "шестьдесят" to 60,
        "семьдесят" to 70, "восемьдесят" to 80, "девяносто" to 90, "сто" to 100,
        "двести" to 200, "триста" to 300, "четыреста" to 400, "пятьсот" to 500,
        "шестьсот" to 600, "семьсот" to 700, "восемьсот" to 800, "девятьсот" to 900
    )

    fun norm(s: String): String = s.lowercase().replace('ё', 'е')
        .replace(Regex("[^a-zа-я0-9:.,\\s]"), " ")
        .replace(Regex("[.,]+(?=\\s|$)"), "")
        .replace(Regex("\\s+"), " ").trim()

    /** Схлопывает двойные буквы: «металлика» == «металика». */
    fun collapse(s: String): String = s.replace(Regex("([a-zа-я])\\1+"), "\$1")

    fun translit(s: String): String {
        val sb = StringBuilder()
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c !in 'a'..'z') { sb.append(c); i++; continue }
            val two = if (i + 1 < s.length) s.substring(i, i + 2) else ""
            val d = when (two) {
                "sh" -> "ш"; "ch" -> "ч"; "th" -> "т"; "ph" -> "ф"; "ck" -> "к"; "oo" -> "у"
                "ee" -> "и"; "ou" -> "ау"; "ya" -> "я"; "yu" -> "ю"; "zh" -> "ж"; "ie" -> "и"; "ea" -> "и"
                else -> null
            }
            if (d != null) { sb.append(d); i += 2; continue }
            sb.append(
                when (c) {
                    'a' -> "а"; 'b' -> "б"; 'c' -> "к"; 'd' -> "д"; 'e' -> "е"; 'f' -> "ф"; 'g' -> "г"
                    'h' -> "х"; 'i' -> "и"; 'j' -> "дж"; 'k' -> "к"; 'l' -> "л"; 'm' -> "м"; 'n' -> "н"
                    'o' -> "о"; 'p' -> "п"; 'q' -> "к"; 'r' -> "р"; 's' -> "с"; 't' -> "т"; 'u' -> "у"
                    'v' -> "в"; 'w' -> "в"; 'x' -> "кс"; 'y' -> "и"; else -> "з"
                }
            )
            i++
        }
        return sb.toString()
    }

    /** «двадцать пять минут» -> «25 минут». */
    fun numberize(s: String): String {
        val out = ArrayList<String>()
        var run = -1
        for (w in s.split(" ")) {
            val v = NUM[w]
            if (v != null) {
                run = (if (run < 0) 0 else run) + v
            } else {
                if (run >= 0) { out.add(run.toString()); run = -1 }
                out.add(w)
            }
        }
        if (run >= 0) out.add(run.toString())
        return out.joinToString(" ")
    }

    /** «1:30» или «1:02:03» -> миллисекунды. */
    fun parseClock(t: String): Long? {
        val m = Regex("(\\d{1,2}):(\\d{2})(?::(\\d{2}))?").find(t) ?: return null
        val a = m.groupValues[1].toLong()
        val b = m.groupValues[2].toLong()
        val c = m.groupValues[3]
        return if (c.isEmpty()) (a * 60 + b) * 1000 else (a * 3600 + b * 60 + c.toLong()) * 1000
    }

    /** «2 минуты 30 секунд», «полчаса», «полторы минуты» -> миллисекунды. Вход — после numberize. */
    fun parseDuration(raw: String): Long? {
        var t = raw
        t = t.replace(Regex("полтора\\s+час[а-я]*"), "90 мин")
        t = t.replace(Regex("полторы\\s+мин[а-я]*"), "90 сек")
        t = t.replace(Regex("пол\\s?часа"), "30 мин")
        t = t.replace(Regex("пол\\s?минуты"), "30 сек")
        // «минуту тридцать» -> «1 мин 30 сек»
        t = t.replace(Regex("(\\d+)\\s*мин[а-я]*\\s+(\\d+)(?!\\s*(?:час|мин|сек|:))"), "\$1 мин \$2 сек")
        val re = Regex("(\\d+(?:[.,]\\d+)?)?\\s*(час(?:а|ов)?|мин(?:ут[а-я]*)?|сек(?:унд[а-я]*)?)(?![а-я])")
        var total = 0.0
        var found = false
        for (m in re.findAll(t)) {
            val n = m.groupValues[1].replace(',', '.').toDoubleOrNull() ?: 1.0
            val mult = when (m.groupValues[2][0]) { 'ч' -> 3600.0; 'м' -> 60.0; else -> 1.0 }
            total += n * mult * 1000
            found = true
        }
        return if (found && total > 0) total.toLong() else null
    }

    fun plural(n: Long, one: String, few: String, many: String): String {
        val m100 = n % 100
        val m10 = n % 10
        return when {
            m100 in 11..14 -> many
            m10 == 1L -> one
            m10 in 2..4 -> few
            else -> many
        }
    }

    fun spoken(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        val parts = ArrayList<String>()
        if (h > 0) parts.add("$h ${plural(h, "час", "часа", "часов")}")
        if (m > 0) parts.add("$m ${plural(m, "минуту", "минуты", "минут")}")
        if (sec > 0 && h == 0L) parts.add("$sec ${plural(sec, "секунду", "секунды", "секунд")}")
        return if (parts.isEmpty()) "0 секунд" else parts.joinToString(" ")
    }

    fun fmt(ms: Long): String {
        val s = maxOf(0L, ms) / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
    }
}
