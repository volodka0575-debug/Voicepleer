package app.voiceplayer

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        PlayerHolder.init(this)
        Wake.load(this)
    }
}
