package app.voiceplayer

import android.content.Context
import android.os.Build
import android.provider.MediaStore

object MusicLibrary {
    @Volatile
    var tracks: List<Track> = emptyList()

    fun scan(ctx: Context) {
        val list = ArrayList<Track>()
        val collection = if (Build.VERSION.SDK_INT >= 29)
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATE_ADDED
        )
        val sel = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 20000"
        try {
            ctx.contentResolver.query(collection, proj, sel, null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { c ->
                val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val iT = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val iA = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val iAl = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val iD = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val iDa = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
                while (c.moveToNext()) {
                    val id = c.getLong(iId)
                    var artist = c.getString(iA) ?: ""
                    if (artist == "<unknown>" || artist.isBlank()) artist = "Неизвестный исполнитель"
                    var album = c.getString(iAl) ?: ""
                    if (album == "<unknown>") album = ""
                    list.add(
                        Track(
                            id = id,
                            title = c.getString(iT) ?: "Без названия",
                            artist = artist,
                            album = album,
                            durationMs = c.getLong(iD),
                            uri = android.content.ContentUris.withAppendedId(
                                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id
                            ),
                            added = c.getLong(iDa)
                        )
                    )
                }
            }
        } catch (_: SecurityException) {
        }
        tracks = list
    }

    /** Нечёткий поиск по названию/исполнителю/альбому (с транслитом и падежами). */
    fun search(query: String): List<Track> {
        val all = tracks
        if (all.isEmpty()) return emptyList()
        val toks = Ru.collapse(Ru.norm(query)).split(" ").filter { it.isNotBlank() }
        if (toks.isEmpty()) return emptyList()
        val stems = toks.map { it.dropLast(if (it.length >= 7) 2 else if (it.length >= 5) 1 else 0) }
        val scored = all.map { tr ->
            tr to stems.count { s -> tr.hay.contains(s) || tr.hayTr.contains(s) }
        }
        val best = scored.maxOf { it.second }
        if (best == 0 || best * 10 < toks.size * 6) return emptyList()
        return scored.filter { it.second == best }.map { it.first }
    }
}
