package app.voiceplayer

import android.content.Context

/** Имя плеера (слово активации) и нечёткое сравнение. */
object Wake {
    @Volatile
    var name: String = "плеер"

    fun load(ctx: Context) {
        name = ctx.getSharedPreferences("vp", Context.MODE_PRIVATE).getString("name", "плеер") ?: "плеер"
    }

    fun set(ctx: Context, n: String) {
        name = Ru.norm(n)
        ctx.getSharedPreferences("vp", Context.MODE_PRIVATE).edit().putString("name", name).apply()
    }

    private fun key(s: String) = Ru.collapse(Ru.translit(Ru.norm(s)))

    private fun lev(a: String, b: String): Int {
        val d = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) d[i][0] = i
        for (j in 0..b.length) d[0][j] = j
        for (i in 1..a.length) for (j in 1..b.length) {
            val c = if (a[i - 1] == b[j - 1]) 0 else 1
            d[i][j] = minOf(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + c)
        }
        return d[a.length][b.length]
    }

    private fun tokMatch(tok: String, nameTok: String): Boolean {
        val a = key(tok)
        val b = key(nameTok)
        if (a.isEmpty() || b.isEmpty()) return false
        val tol = if (b.length >= 7) 2 else if (b.length >= 4) 1 else 0
        return lev(a, b) <= tol
    }

    private fun nameTokens() = Ru.norm(name).split(" ").filter { it.isNotBlank() }

    fun contains(text: String): Boolean {
        val toks = Ru.norm(text).split(" ").filter { it.isNotBlank() }
        val nts = nameTokens()
        return nts.isNotEmpty() && nts.all { nt -> toks.any { tokMatch(it, nt) } }
    }

    /** Убирает имя из фразы. */
    fun strip(text: String): String {
        val toks = Ru.norm(text).split(" ").filter { it.isNotBlank() }.toMutableList()
        for (nt in nameTokens()) {
            val i = toks.indexOfFirst { tokMatch(it, nt) }
            if (i >= 0) toks.removeAt(i)
        }
        return toks.joinToString(" ")
    }
}
